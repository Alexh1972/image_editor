#include "application.h"

int main(void)
{
	run();
}