int **allocate_matrix(int height, int width);

void free_matrix(int **matrix, int height);

void free_image_resources(image *image);