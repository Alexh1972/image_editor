#include "image.h"

void select_from_image(image *image);

void print_histogram(image *image);

void rotate_image(image *image);

void apply_effect(image *image);

void save_image(image *image);